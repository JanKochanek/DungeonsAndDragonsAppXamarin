﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Xamarin.Forms;

namespace DungeonsAndDragonsApp.Model
{
    class SideOptions
    {
        public string SideDisplayName { get; set; }

        public int NumberOfSides { get; set; }
    }
}
