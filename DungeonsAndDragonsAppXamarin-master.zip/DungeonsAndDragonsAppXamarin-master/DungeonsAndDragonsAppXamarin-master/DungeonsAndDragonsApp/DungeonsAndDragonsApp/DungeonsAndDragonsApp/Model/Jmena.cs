﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Xamarin.Forms;
using SQLite;

namespace DungeonsAndDragonsApp.Model
{
    public class Jmena : ContentPage
    {
        [PrimaryKey, AutoIncrement]
        public int id
        {
            get;
            set;
        }
        public string jmena
        {
            get;
            set;
        }
        public string kategorie
        {
            get;
            set;
        }
        public string pohlavi
        {
            get;
            set;
        }
    }
}