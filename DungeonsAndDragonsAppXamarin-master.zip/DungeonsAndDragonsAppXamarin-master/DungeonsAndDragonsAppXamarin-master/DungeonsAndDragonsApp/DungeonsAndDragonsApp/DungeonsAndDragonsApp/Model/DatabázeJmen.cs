﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Xamarin.Forms;
using SQLite;
using System.Threading.Tasks;

namespace DungeonsAndDragonsApp.Model
{
    public class DatabázeJmen : ContentPage
    {
        readonly SQLiteAsyncConnection Databaze;

        public DatabázeJmen(string Cesta)
        {
            Databaze = new SQLiteAsyncConnection(Cesta);
            Databaze.CreateTableAsync<Jmena>().Wait();
        }

        public Task<List<Jmena>> GetJmenaAsync()
        {
            return Databaze.Table<Jmena>().ToListAsync();
        }

        public Task<Jmena> GetJmenaAsync(int id)
        {
            return Databaze.Table<Jmena>().Where(i => i.id == id).FirstOrDefaultAsync();

        }

        public Task<int> SaveJmenaAsync(Jmena jmenoPostavy)
        {
            if (jmenoPostavy.id == 0)
            { 
                return Databaze.UpdateAsync(jmenoPostavy);
            }
            else
            {
                return Databaze.InsertAsync(jmenoPostavy);
            }
        }

        public Task<int> DeleteJmenaAsync(Jmena jmenoPostavy)
        {
            return Databaze.DeleteAsync(jmenoPostavy);
        }
    }
}